public interface View{
  void stateChanged();
}
